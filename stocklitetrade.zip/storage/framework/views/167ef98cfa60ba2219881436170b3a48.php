﻿
<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $attributes = $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $component = $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>

    <!--  Header End -->


    <div class="body-wrapper">
        <div class="container-fluid">
          <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
            <div class="card-body px-4 py-4">
              <div class="row align-items-center">
                <div class="col-9">
                  <h4 class="fw-semibold mb-8">New Blog </h4>
                  <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item">
                        <a class="text-muted text-decoration-none" href="https://bootstrapdemos.adminmart.com/modernize/dist/main//">Home</a>
                      </li>
                      <li class="breadcrumb-item" aria-current="page">create Blog</li>
                    </ol>
                  </nav>
                </div>

              </div>
            </div>
          </div>
          <form class="row" action="<?php echo e(route('blog.new.article')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="col-lg-12 ">
              <div class="card">
                <div class="card-body">

                  <div  class="form-horizontal">
                    <div class="mb-4">
                      <label class="form-label">Add Title.. <span class="text-danger">*</span>
                      </label>
                      <input type="text" class="form-control" placeholder="Add a title ..." name="title">
                    </div>
                    <div>
                      <label class="form-label">Description <span class="text-danger">*</span></label>
                      <div>

                        <div id="editor" style="min-height: 30vh" name="html">
                        </div>
                      </div>
                    </div>
                </div>
                </div>
              </div>

              <div class="card">
                <div class="card-body">
                  <h4 class="card-title mb-7">Media <span class="text-danger">*</span></h4>

                  <div class="form-group">
                    <div class="mb-2">
                        <label for="back-id" class="d-block border cursor-pointer">
                            <input type="file" class="d-none" name="back_id" id="back-id" class="form-control"
                            placeholder="Upload ID">
                            <img src="<?php echo e(asset('assets\images\custom\id_placeholder.jpg')); ?>" alt="upload"
                            class="d-block ratio ratio-16x9 object-fit-cover" name="file">
                        </label>
                    </div>
                </div>
                </div>
              </div>

             <div class="row">

                <div class="col-lg-6">

                    <textarea name="description" placeholder="Write a description" id="" cols="30" rows="10" required="" class="form-control shadow-sm p-3 fw-bold mb-3"></textarea>
            </div>
            <div class="col-lg-6">


              <div class="card">


                <div class="card-body">
                <h4 class="card-title mb-7">Feature image <span class="text-danger">*</span></h4>
                <div class="form-group">
                    <div class="mb-2">
                        <label for="back-id" class="d-block border cursor-pointer">
                            <input type="file" class="d-none" name="back_id" id="back-id" class="form-control"
                            placeholder="Upload ID">
                            <img src="<?php echo e(asset('assets\images\custom\id_placeholder.jpg')); ?>" alt="upload"
                            class="d-block ratio ratio-16x9 object-fit-cover">
                        </label>
                    </div>
                </div>
            </div>
        </div>
            </div>

            </div>

            <div class="card">
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-7">
                    <h4 class="card-title">Status <span class="text-danger">*</span></h4>
                    <div class="p-2 h-100 bg-success rounded-circle"></div>
                  </div>
                  <div action="" class="form-horizontal">
                    <div>
                      <select class="form-select mr-sm-2  mb-2" id="inlineFormCustomSelect">
                        <option selected="">Published</option>
                        <option value="1">Draft</option>
                        <option value="2">Sheduled</option>
                        <option value="3">Inactive</option>
                      </select>
                      <p class="fs-2 mb-0">
                        Set the product status.
                      </p>
                    </div>
                </div>
                </div>
              </div>


              <div class="form-actions mb-5">
                <button type="submit" class="btn btn-primary">
                  Save changes
                </button>
                <button type="button" class="btn bg-danger-subtle text-danger ms-6">
                  Cancel
                </button>
              </div>
            </div>

        </form>
        </div>
      </div>

    <?php if (isset($component)) { $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $attributes = $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $component = $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>

  </div>
  <?php if (isset($component)) { $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $attributes = $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $component = $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\admin\new-blog.blade.php ENDPATH**/ ?>