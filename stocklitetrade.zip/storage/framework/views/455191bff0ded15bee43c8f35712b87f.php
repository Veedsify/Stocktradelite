﻿
<?php $__env->startSection('content'); ?>
    <div id="main-wrapper">
        <!-- Sidebar Start -->
        <?php if (isset($component)) { $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $attributes = $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $component = $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
        <!--  Sidebar End -->

        <div class="page-wrapper">
            <!--  Header Start -->
            <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>

            <!--  Header End -->


            <div class="body-wrapper">
                <div class="container-fluid">
                    <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
                        <div class="card-body px-4 py-3">
                            <div class="row align-items-center">
                                <div class="col-9">
                                    <h4 class="fw-semibold mb-8">Users</h4>
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item">
                                                <a class="text-muted text-decoration-none" href="/">Home</a>
                                            </li>
                                            <li class="breadcrumb-item" aria-current="page">users</li>
                                        </ol>
                                    </nav>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="datatables">
                        <!-- basic table -->
                        <div class="row">
                            <div class="col-12">
                                <!-- start User Datatable -->
                                <div class="card">
                                    <div class="card-body">
                                        <div class="mb-2">
                                            <h5 class="mb-0">User Datatable</h5>
                                        </div>
                                        <div class="table-responsivPe">
                                            <table id="zero_config"
                                                class="table border table-striped table-bordered text-nowrap align-middle">
                                                <thead>
                                                    <!-- start row -->
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Tier</th>
                                                        <th>Email</th>
                                                        <th>Phone</th>
                                                        <th>Deposits</th>
                                                        <th>Balance</th>
                                                        <th> Role</th>
                                                        <th>Edit Trades</th>
                                                    </tr>
                                                    <!-- end row -->
                                                </thead>
                                                <tbody>
                                                    <!-- start row -->
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($user->name); ?></td>
                                                            <td><?php echo e(\App\Models\Tier::where('id', $user->tier)->first()->name); ?>

                                                            </td>
                                                            <td><?php echo e($user->email); ?></td>
                                                            <td><?php echo e($user->phone); ?></td>
                                                            <td>
                                                                <a href="<?php echo e(route('admin.orders', [$user->id])); ?>"
                                                                    class=" text-decoration-underline text-neutral-950 ">
                                                                    View Deposits
                                                                </a>
                                                            </td>
                                                            <td>$<?php echo e(number_format($user->balance)); ?></td>
                                                            <td>
                                                                <form class="d-flex gap-1"
                                                                action="<?php echo e(route('admin.users.upgrade', $user->id)); ?>"
                                                                method="post">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <select name="role" id="role"
                                                                    class="px-1 py-1 border-1 border-muted btn-outline-info rounded-2">
                                                                    <option value="user"
                                                                        <?php echo e($user->role === 'user' ? 'selected' : ''); ?>>User
                                                                    </option>
                                                                    <option value="admin"
                                                                        <?php echo e($user->role === 'admin' ? 'selected' : ''); ?>>Admin
                                                                    </option>

                                                                </select>
                                                                <button type="submit"
                                                                    class="btn btn-primary btn-sm">Update</button>
                                                            </form>
                                                                </td>
                                                            <td>
                                                                <a href="<?php echo e(route('admin.balance.editbalance', $user->id)); ?>"
                                                                    class="btn-sm btn btn-primary">Edit</a>
                                                            </td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <!-- end row -->
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                <!-- end Alternative Pagination -->
                            </div>
                        </div>

                    </div>


                </div>
            </div>

            <?php if (isset($component)) { $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $attributes = $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $component = $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>

        </div>
        <?php if (isset($component)) { $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $attributes = $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $component = $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>




    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\admin\users.blade.php ENDPATH**/ ?>