<?php if(session('success')): ?>
<script>
    swal({
            title: "Success!",
            text: "<?php echo e(session('success')); ?>",
            icon: "success",
            button: "OK",
          })
</script>
<?php endif; ?>
<?php if(session('error')): ?>
<script>
    swal({
            title: "Error!",
            text: "<?php echo e(session('error')); ?>",
            icon: "error",
            button: "OK",
          })
</script>
<?php endif; ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\components\pages\alerts.blade.php ENDPATH**/ ?>