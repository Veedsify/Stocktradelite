<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal653dcfd80dd6333300d626f39c07d6a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $attributes = $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $component = $__componentOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal16952127c672c67c3b5e12b22e860292 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16952127c672c67c3b5e12b22e860292 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $attributes = $__attributesOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__attributesOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $component = $__componentOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__componentOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>

    <!--  Header End -->


    <div class="body-wrapper">
      <div class="container-fluid ">
        <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
          <div class="card-body px-4 py-3">
            <div class="row align-items-center">
              <div class="col-9">
                <h4 class="fw-semibold mb-8">KYC</h4>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a class="text-muted text-decoration-none" href="/">Home</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">KYC</li>
                  </ol>
                </nav>
              </div>

            </div>
          </div>
        </div>


        <div class="row">
          <div class="col-12 p-0">
            <div class="col-12 p-0 card shadow-none border">
              <div class=" w-100 card-body">
                <h5 class=" card-title fw-semibold mb-5">KYC verification</h5>
                <?php if(empty($verification)): ?>
                <form action="<?php echo e(route('kyc.submit')); ?>" method="POST" class=m-0" enctype="multipart/form-data"
                  id="kyc-form">
                  <?php echo csrf_field(); ?>
                  <div class="row">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-body">
                          <label class="form-label">
                            Select Identification Type <span class="text-danger">*</span>
                          </label>
                          <select required name="id_type" class="form-select form-select-lg px-3 py-3 mr-sm-2">
                            <option disabled label="Select an Option" selected></option>
                            <option value="National ID">National ID</option>
                            <option value="Social Security Number">Social Security Number (SSN)</option>
                            <option value="Drivers Lisence">Drivers Licence</option>
                            <option value="Employer Identification Number">Employer Identification Number (EIN)</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title mb-2">Front</h4>
                          <div class="form-group">
                            <div class="mb-3">
                              <label for="front-id" class="d-block border cursor-pointer">
                                <input type="file" class="d-none" id="front-id" name="front_id" class="form-control"
                                  placeholder="Upload ID">
                                <img src="<?php echo e(asset('assets\images\custom\id_placeholder.jpg')); ?>" alt="upload"
                                  class="d-block ratio ratio-16x9 object-fit-cover">
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title mb-2">Back</h4>
                          <div class="form-group">
                            <div class="mb-3">
                              <label for="back-id" class="d-block border cursor-pointer">
                                <input type="file" class="d-none" name="back_id" id="back-id" class="form-control"
                                  placeholder="Upload ID">
                                <img src="<?php echo e(asset('assets\images\custom\id_placeholder.jpg')); ?>" alt="upload"
                                  class="d-block ratio ratio-16x9 object-fit-cover">
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-body">
                          <input type="submit" class="p-3 py-3 mr-sm-2 btn btn-lg btn-primary w-100" value="Submit">
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
                <?php elseif( $verification->status == "pending"): ?>
                <div class="alert alert-warning" role="alert">
                  <h4 class="alert-heading">Pending</h4>
                  <p>Your KYC verification is pending.
                    we will notify you once your verification is complete.</p>
                  <h5>
                    <span class="fw-semibold">ID Type:</span> <?php echo e($verification->verification_type); ?>

                  </h5>
                  <h5>
                    <span class="fw-semibold">Status:</span> <?php echo e($verification->status); ?>

                  </h5>
                  <p>
                    You can't submit another verification until this is complete.
                  </p>
                </div>
                <?php elseif($verification->status == "rejected"): ?>
                <div class="alert alert-danger" role="alert">
                  <h4 class="alert-heading">
                    Rejected
                  </h4>
                  <p>Your KYC verification has been rejected,
                    you cannot submit another verification.
                  </p>
                  <div class="row">
                    <div class="col-12">
                      <div class="card bg-transparent">
                        <div class="card-body">
                          <h4 class="card-title">
                            <span class="fw-semibold">ID Type:</span> <?php echo e($verification->verification_type); ?>

                          </h4>
                          <h4 class="card-title">
                            <span class="fw-semibold">Status:</span> <?php echo e($verification->status); ?>

                          </h4>
                          <h4 class="card-title">
                            <span class="fw-semibold">Date:</span> <?php echo e($verification->updated_at->format('d M Y h:i A')); ?>

                          </h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php else: ?>
                <div class="alert alert-success" role="alert">
                  <h4 class="alert-heading">Verified</h4>
                  <p>Your KYC verification has been verified. You can now proceed to trade.</p>
                  <div class="row">
                    <div class="col-12">
                      <div class="card">
                        <div class="card-body">
                          <h4 class="card-title">
                            <span class="fw-semibold">ID Type:</span> <?php echo e($verification->verification_type); ?>

                          </h4>
                          <h4 class="card-title">
                            <span class="fw-semibold">Status:</span> <?php echo e($verification->status); ?>

                          </h4>
                          <h4 class="card-title">
                            <span class="fw-semibold">Date:</span> <?php echo e($verification->updated_at->format('d M Y h:i A')); ?>

                          </h4>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
        <?php if (isset($component)) { $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $attributes = $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $component = $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>
      </div>
      <?php if (isset($component)) { $__componentOriginal8f1c59407c428ae30b30a6af53f04baf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $attributes = $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $component = $__componentOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>




    </div>


    <script>
      function copyText(inputId) {
      var input = document.getElementById(inputId);

      if (input && input.value) {
        // Create a temporary input element
        var tempInput = document.createElement('input');
        tempInput.setAttribute('type', 'text');
        tempInput.setAttribute('value', input.value);
        document.body.appendChild(tempInput);

        // Select the text in the temporary input
        tempInput.select();
        tempInput.setSelectionRange(0, 99999); // For mobile devices

        // Copy the selected text
        document.execCommand('copy');

        // Clean up - remove the temporary input element
        document.body.removeChild(tempInput);

        // Visual feedback - change button text to 'Copied!' temporarily
        var copyButton = input.nextElementSibling.querySelector('.btn-primary');
        copyButton.innerText = 'Copied!';
        setTimeout(function() {
          copyButton.innerText = 'Copy';
        }, 1500); // Reset button text after 1.5 seconds
      }
    }
    </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/user/userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\user\kyc.blade.php ENDPATH**/ ?>