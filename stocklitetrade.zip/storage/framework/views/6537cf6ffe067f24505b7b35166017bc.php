﻿
<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $attributes = $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $component = $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>

    <!--  Header End -->


    <div class="body-wrapper">
      <div class="container-fluid">
        <!--  Owl carousel -->
        <div class="row">
          <div class="col-sm-12">
            <div class="card bg-primary-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center mb-3">
                  <h6 class="mb-0">Total Balance <span>$</span></h6>
                </div>
                <form action="<?php echo e(route('admin.balance.edit', $user->id)); ?>" method="post" class="row">
                  <?php echo csrf_field(); ?>
                  <div class="d-flex align-items-center justify-content-between fs-7 col-sm-12 col-md-9 mb-3 m-mb-0">
                    <input type="number" name="total_balance" value="<?php echo e($user->balance ? $user->balance : 0); ?>" id=""
                      class="form-control fs-7 bg-white">
                  </div>
                  <div class="col-sm-12 col-md-3">
                    <button class="col-6 fs-6 w-100 btn btn-primary">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card bg-primary-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center mb-3">
                  <h6 class="mb-0">Total Trade <span>$</span></h6>
                </div>
                <form class="row" action="<?php echo e(route('admin.trades.edit', $user->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="d-flex align-items-center justify-content-between fs-7 col-sm-12 col-md-8 mb-3 m-mb-0">
                    <input type="number" name="user_trades" id="" class="form-control fs-7 bg-white"
                      value="<?php echo e($user->trades->first()->total_count ?? 0); ?>">
                  </div>
                  <div class="col-sm-12 col-md-4">
                    <button class="col-6 fs-6 w-100 btn btn-primary">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-sm-6">
            <div class="card bg-primary-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center mb-3">
                  <h6 class="mb-0">Today Changes <span>$</span></h6>
                </div>
                <form class="row" action="<?php echo e(route('admin.profits.edit', $user->id)); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="d-flex align-items-center justify-content-between fs-7 col-sm-12 col-md-8 mb-3 m-mb-0">
                    <input type="number" name="total_changes_today" id="" class="form-control fs-7 bg-white" required
                      value="<?php echo e(0); ?>">
                  </div>
                  <div class="col-sm-12 col-md-4">
                    <button class="col-6 fs-6 w-100 btn btn-primary">Save</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div class="mt-5 mb-5">
          <h2>
            User Account Changes
          </h2>
        </div>

        <div class="table-responsive">
          <table id="zero_config" class="table border table-striped table-bordered text-nowrap align-middle">
            <thead>
              <!-- start row -->
              <tr>
                <th>Name</th>
                <th>Profits</th>
                <th>
                  Date
                </th>
              </tr>
              <!-- end row -->
            </thead>
            <tbody>
              <?php $__currentLoopData = $profits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($profit->user->name); ?></td>
                <td>$ <?php echo e($profit->total_profit); ?></td>
                <td><?php echo e($profit->created_at->format('D M Y h:i A')); ?></td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      <?php if (isset($component)) { $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $attributes = $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $component = $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>

    </div>
    <?php if (isset($component)) { $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $attributes = $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $component = $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>




  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\admin\balance-edit.blade.php ENDPATH**/ ?>