﻿
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalfc88abadc63b6694f60975da4d0e2187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc88abadc63b6694f60975da4d0e2187 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $attributes = $__attributesOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $component = $__componentOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__componentOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<!-- PageTitle -->
<section class="page-title">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h3 class="heading">Login</h3>
      </div>
      <div class="col-md-6">
        <ul class="breadcrumb">
          <li><a href="/">Home</a></li>
          <li>
            <p class="fs-18">/</p>
          </li>
          <li>
            <p class="fs-18">
              Reset Password
            </p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- End PageTitle -->

<section class="register login">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block-text center">
          <h3 class="heading">
            Create a new password
          </h3>
        </div>
      </div>
      <div class="col-md-12">
        <div class="flat-tabs">
          <div class="content-tab">
            <div class="content-inner">
              <form action="<?php echo e(route('reset.password.save', [$token])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <ul>
                    <li class="text-center"><?php echo e(session('error')); ?></li>
                  </ul>
                </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <ul>
                    <li class="text-center"><?php echo e(session('success')); ?></li>
                  </ul>
                </div>
                <?php endif; ?>
                <div class="form-group">
                  <label>
                    New Password
                    <span class="fs-14">
                      <?php echo e($errors->first('password')); ?>

                    </span>
                  </label>
                  <input type="password" class="form-control" name="password" placeholder="Please fill in the password."
                    value="<?php echo e(old('password')); ?>">
                </div>
                <div class="form-group s1">
                  <label>
                    Confirm Password
                    <span class="fs-14">
                      <?php echo e($errors->first('confirm_password')); ?>

                    </span>
                  </label>
                  <input type="password" class="form-control" placeholder="Please confirm your password."
                    name="confirm_password" value="<?php echo e(old('confirm_password')); ?>">
                </div>
                <button type="submit" class="btn-action">
                  Save
                </button>
                <div class="bottom">
                  <p>Not a member?</p>
                  <a href="<?php echo e(route('register')); ?>">Register</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-sale">
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class="block-text">
          <h4 class="heading">Earn up to $25 worth of crypto</h4>
          <p class="desc">
            Discover how specific cryptocurrencies work — and get a bit of
            each crypto to try out for yourself.
          </p>
        </div>
      </div>
      <div class="col-md-5">
        <div class="button">
          <a href="#">Create Account</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Reset',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\reset.blade.php ENDPATH**/ ?>