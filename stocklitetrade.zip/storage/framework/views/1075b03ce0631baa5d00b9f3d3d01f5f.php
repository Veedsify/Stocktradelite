﻿

<?php $__env->startSection('content'); ?>

<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal653dcfd80dd6333300d626f39c07d6a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $attributes = $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $component = $__componentOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal16952127c672c67c3b5e12b22e860292 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16952127c672c67c3b5e12b22e860292 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $attributes = $__attributesOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__attributesOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $component = $__componentOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__componentOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>

    <!--  Header End -->


    <div class="body-wrapper">
      <div class="container-fluid ">
        <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
          <div class="card-body px-4 py-3">
            <div class="row align-items-center">
              <div class="col-9">
                <h4 class="fw-semibold mb-8">Change Password</h4>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a class="text-muted text-decoration-none" href="/">Home</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">Change Password</li>
                  </ol>
                </nav>
              </div>

            </div>
          </div>
        </div>


        <div class="row">

          <div class="col-12 p-0">
            <div class="col-12 p-0 card shadow-none border">
              <div class=" w-100 card-body">
                <div class=" m-0 ">
                  <h5 class="card-title fw-semibold">Update Password</h5>

                  <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                    <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <?php endif; ?>

                  <form action="<?php echo e(route('changepassword.submit')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                      <div class="col-12 mb-3 mt-3">
                        <div>
                          <label class="form-label">Current Password</label>
                          <input type="password" class="form-control" name="current_password"
                            placeholder="Enter Current Password">
                        </div>
                      </div>
                      <div class="col-12 mb-3">
                        <div>
                          <label class="form-label">New Password</label>
                          <input type="password" class="form-control" name="password" placeholder="Enter New Password">
                        </div>
                      </div>
                      <div class="col-12 mb-3">
                        <div>
                          <label class="form-label">Confirm Password</label>
                          <input type="password" class="form-control" name="confirm_password"
                            placeholder="Re-enter New Password">
                        </div>
                      </div>

                      <div class="col-12">
                        <div class="mt-2 ">
                          <button class="btn btn-primary col-lg-6 col-12">Update </button>
                        </div>
                      </div>
                    </div>
                  </form>

                </div>
              </div>
            </div>

          </div>
        </div>







        <?php if (isset($component)) { $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $attributes = $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $component = $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>

      </div>
      <?php if (isset($component)) { $__componentOriginal8f1c59407c428ae30b30a6af53f04baf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $attributes = $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $component = $__componentOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>




    </div>
  </div>
</div>

<script>
  function copyText(inputId) {
      var input = document.getElementById(inputId);

      if (input && input.value) {
        // Create a temporary input element
        var tempInput = document.createElement('input');
        tempInput.setAttribute('type', 'text');
        tempInput.setAttribute('value', input.value);
        document.body.appendChild(tempInput);

        // Select the text in the temporary input
        tempInput.select();
        tempInput.setSelectionRange(0, 99999); // For mobile devices

        // Copy the selected text
        document.execCommand('copy');

        // Clean up - remove the temporary input element
        document.body.removeChild(tempInput);

        // Visual feedback - change button text to 'Copied!' temporarily
        var copyButton = input.nextElementSibling.querySelector('.btn-primary');
        copyButton.innerText = 'Copied!';
        setTimeout(function() {
          copyButton.innerText = 'Copy';
        }, 1500); // Reset button text after 1.5 seconds
      }
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/user/userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\user\change-password.blade.php ENDPATH**/ ?>