﻿
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalfc88abadc63b6694f60975da4d0e2187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc88abadc63b6694f60975da4d0e2187 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $attributes = $__attributesOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $component = $__componentOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__componentOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<!-- PageTitle -->
<section class="page-title">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h3 class="heading">
          <?php echo e($privacyContent->title ?? "Privacy Policy"); ?>

        </h3>
      </div>
      <div class="col-md-6">
        <ul class="breadcrumb">
          <li><a href="/">Home</a></li>
          <li>
            <p class="fs-18">/</p>
          </li>
          <li>
            <p class="fs-18">Privacy Policy</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- End PageTitle -->

<section class="blog-details">
  <div class="container">
    <div class="row">
      <div class="col-xl-8 col-md-12">
        <div class="blog-main">
          <div class="content">
            <?php echo $privacyContent->content ?? "<p>Policy Page</p>"; ?>


          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-sale">
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class="block-text">
          <h4 class="heading">Signup and Earn higher profits here on Stocklitetrade</h4>
          <p class="desc">
            Discover how specific cryptocurrencies work — and get a bit of
            each crypto to try out for yourself.
          </p>
        </div>
      </div>
      <div class="col-md-5">
        <div class="button">
          <a href="#">Create Account</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Privacy Policy',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\privacy.blade.php ENDPATH**/ ?>