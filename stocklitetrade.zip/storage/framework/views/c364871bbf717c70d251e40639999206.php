﻿
<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $attributes = $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $component = $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
  <!--  Sidebar End -->
  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
    <div class="body-wrapper">
      <div class="container-fluid">
        <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
          <div class="card-body px-4 py-3">
            <div class="row align-items-center">
              <div class="col-9">
                <h4 class="fw-semibold mb-8">Upgrade Requests
                  For <?php echo e($user->name); ?>

                </h4>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a class="text-muted text-decoration-none" href="/">Home</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                      Upgrade Requests
                    </li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <div class="datatables">
          <!-- basic table -->
          <div class="row">
            <div class="col-12">
              <!-- start User Datatable -->
              <div class="card">
                <div class="card-body">
                  <div class="mb-2">
                    <h5 class="mb-0">Upgrade Datatable</h5>
                  </div>
                  <div class="table-responsive">
                    <table id="zero_config" class="table border table-striped table-bordered text-nowrap align-middle">
                      <thead>
                        <!-- start row -->
                        <tr>
                          <th>Name</th>
                          <th>Amount</th>
                          <th>Status</th>
                          <th>Payment Method</th>
                          <th>Payment Proof</th>
                          <th>Type</th>
                          <th>Action</th>
                          <th>Date</th>
                        </tr>
                        <!-- end row -->
                      </thead>
                      <tbody>
                        <!-- start row -->
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($deposit->user->name); ?>

                          </td>
                          <td>$
                            <?php echo e(number_format($deposit->amount)); ?>

                          </td>
                          <td>
                            <div
                              class="text-capitalize badge p-2 <?php echo e($deposit->status == 'pending' ? 'badge-warning text-warning' : ($deposit->status == 'approved' ? 'badge-success text-success' : 'badge-danger text-danger')); ?>">
                              <?php echo e($deposit->status); ?>

                            </div>
                          </td>
                          <td>
                            <?php echo e($deposit->payment_method); ?>

                          </td>
                          <td>
                            <a href="<?php echo e(asset($deposit->payment_proof)); ?>" style="text-decoration: underline;"
                              download>Download
                              Receipt</a>
                            <br>
                          </td>
                          <td>
                            <?php echo e($deposit->is_upgrade ? 'Upgrade' : 'Deposit'); ?>

                          </td>
                          <td>
                            <form class="d-flex gap-1" action="<?php echo e(route('admin.deposit.update', [
                                'id' => $deposit->id,
                                'tier'=> $deposit->is_upgrade ? 'upgrade' : 'deposit',
                              ])); ?>" method="post">
                              <?php echo csrf_field(); ?>
                              <select name="deposit_status" id="verification_status"
                                class="px-1 py-1 border-1 border-muted btn-outline-info rounded-2">
                                <option value="pending" <?php echo e($deposit->status == 'pending' ? 'selected' : ''); ?>

                                  >Pending
                                </option>
                                <option value="approved" <?php echo e($deposit->status == 'approved' ? 'selected' : ''); ?>

                                  >Approved
                                </option>
                                <option value="declined" <?php echo e($deposit->status == 'rejected' ? 'selected' : ''); ?>

                                  >
                                  Decline
                                </option>
                              </select>
                              <button type="submit" class="btn btn-primary btn-sm">Update</button>
                            </form>
                          </td>
                          <td>
                            <?php echo e($deposit->created_at->format('d M Y h:i A')); ?>

                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- end row -->


                    </table>
                  </div>
                </div>
              </div>
              <!-- end Alternative Pagination -->
            </div>
          </div>

        </div>


      </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $attributes = $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $component = $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>

  </div>
  <?php if (isset($component)) { $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $attributes = $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $component = $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\admin\orders.blade.php ENDPATH**/ ?>