﻿
<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $attributes = $__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__attributesOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2)): ?>
<?php $component = $__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2; ?>
<?php unset($__componentOriginal037203d46cdd29a9086d6dc7fe8ee9b2); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $attributes = $__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__attributesOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2)): ?>
<?php $component = $__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2; ?>
<?php unset($__componentOriginal7a59feeeee8ce3f3cb3543e6971245f2); ?>
<?php endif; ?>
    <div class="body-wrapper">
      <div class="container-fluid">
        <!-- TradingView Widget BEGIN -->
        <div class="row">
          <div class="col-sm-6 col-xl-4">
            <div class="card bg-primary-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center">

                  <h6 class="mb-0">Users</h6>

                </div>
                <div class="d-flex align-items-center justify-content-between mt-3">
                  <h3 class="mb-0 fw-semibold fs-7">
                    <?php echo e(number_format($usersCount)); ?>

                  </h3>
                </div>
                <div class="ms-auto text-info d-flex align-items-center mt-3">
                  <a href="<?php echo e(route('users')); ?>" style="text-decoration:underline; ">View Users</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-xl-4">
            <div class="card bg-success-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center">
                  <h6 class="mb-0">Pending Kyc Requests</h6>
                </div>
                <div class="d-flex align-items-center justify-content-between mt-3">
                  <h3 class="mb-0 fw-semibold fs-7">
                    <?php echo e(number_format($pendingKyc)); ?>

                  </h3>
                </div>
                <div class="ms-auto text-info d-flex align-items-center mt-3">
                  <a href="<?php echo e(route('admin.kyc')); ?>" style="text-decoration:underline; ">View Kyc Requests</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-xl-4">
            <div class="card bg-danger-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center">

                  <h6 class="mb-0">Contact Requests</h6>

                </div>
                <div class="d-flex align-items-center justify-content-between mt-3">
                  <h3 class="mb-0 fw-semibold fs-7">
                    <?php echo e(number_format($contactCount)); ?>

                  </h3>
                </div>
              </div>
            </div>
          </div>
          <div class="col-sm-6 col-xl-4">
            <div class="card bg-warning-subtle shadow-none">
              <div class="card-body p-4">
                <div class="d-flex align-items-center">

                  <h6 class="mb-0">Withdrawal Requests</h6>

                </div>
                <div class="d-flex align-items-center justify-content-between mt-3">
                  <h3 class="mb-0 fw-semibold fs-7">
                    <?php echo e(number_format($pendingWIthdrwal)); ?>

                  </h3>
                </div>
                <div class="ms-auto text-info d-flex align-items-center mt-3">
                  <a href="<?php echo e(route('admin.withdrawals')); ?>" style="text-decoration:underline; ">View Withdrawals</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $attributes = $__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__attributesOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381)): ?>
<?php $component = $__componentOriginalc63cb1ec546b54876e95cd77c8cbc381; ?>
<?php unset($__componentOriginalc63cb1ec546b54876e95cd77c8cbc381); ?>
<?php endif; ?>

  </div>
  <?php if (isset($component)) { $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $attributes = $__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__attributesOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93)): ?>
<?php $component = $__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93; ?>
<?php unset($__componentOriginalc85ce7d04e07b8a8b4f86b4c88bcdc93); ?>
<?php endif; ?>




</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/admin/adminlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\admin\admin.blade.php ENDPATH**/ ?>