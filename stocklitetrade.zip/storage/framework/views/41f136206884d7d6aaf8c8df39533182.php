﻿
<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal653dcfd80dd6333300d626f39c07d6a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $attributes = $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $component = $__componentOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal16952127c672c67c3b5e12b22e860292 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16952127c672c67c3b5e12b22e860292 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $attributes = $__attributesOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__attributesOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $component = $__componentOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__componentOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
    <!--  Header End -->
    <div class="body-wrapper">
      <div class="container-fluid">
        <!--  Owl carousel -->
        <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
          <div class="card-body px-4 py-3">
            <div class="row align-items-center">
              <div class="col-9">
                <h4 class="fw-semibold mb-8">
                  Upgrade Account to <?php echo e($tier->name); ?>

                </h4>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a class="text-muted text-decoration-none" href="/">Home</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">Upgrade</li>
                  </ol>
                </nav>
              </div>
            </div>
          </div>
        </div>
        <div>
          <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
          <?php endif; ?>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title" style="font: 700 !important">BITCOIN</h4>
                <img src="<?php echo e(asset ('user-assets/images/png/bitcoin.jpg')); ?>" alt="" class="w-50 d-block mx-auto">
                <!-- Custom width modal -->
                <button onclick="openModal({node:'deposit_btc'})" type="button"
                  class="btn mb-1 mt-3 bg-primary-subtle w-100 text-primary px-4 fs-4  text-black ">
                  <i class="ti ti-chevrons-right fs-5 "></i>
                  Choose this one
                </button>
              </div>
            </div>
          </div>
          

          <div class="col-md-6">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title" style="font: 700 !important">Ethereum</h4>
                <img src="<?php echo e(asset ('user-assets/images/png/ethereum.png')); ?>" alt="" class="w-50 d-block mx-auto">
                <button onclick="openModal({node:'deposit_eth'})" type="button"
                  class="btn mb-1 mt-3 bg-primary-subtle w-100 text-primary px-4 fs-4  text-black ">
                  <i class="ti ti-chevrons-right fs-5 "></i>
                  Choose this one
                </button>
              </div>
            </div>
          </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal8f1c59407c428ae30b30a6af53f04baf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $attributes = $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $component = $__componentOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
      </div>

      <script>
        const tierData = {
            min: '<?php echo e($tier->min); ?>',
            max: '<?php echo e($tier->max); ?>',
         btc: '<?php echo e($wallet->btc_address ?? ""); ?>',
          eth: '<?php echo e($wallet->eth_address ?? ""); ?>',
        }
      </script>
      

      <?php
      $tierId = $tier->id;
      $action = ['action'=>'upgrade'];
      ?>
      <?php if (isset($component)) { $__componentOriginal76e2d9d1f6e798a0ce3e86662095cf3c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76e2d9d1f6e798a0ce3e86662095cf3c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.deposit-eth-modals','data' => ['wallet' => $wallet,'action' => $action,'tier' => $tierId]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.deposit-eth-modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wallet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($wallet),'action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($action),'tier' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tierId)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76e2d9d1f6e798a0ce3e86662095cf3c)): ?>
<?php $attributes = $__attributesOriginal76e2d9d1f6e798a0ce3e86662095cf3c; ?>
<?php unset($__attributesOriginal76e2d9d1f6e798a0ce3e86662095cf3c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76e2d9d1f6e798a0ce3e86662095cf3c)): ?>
<?php $component = $__componentOriginal76e2d9d1f6e798a0ce3e86662095cf3c; ?>
<?php unset($__componentOriginal76e2d9d1f6e798a0ce3e86662095cf3c); ?>
<?php endif; ?>
      <?php if (isset($component)) { $__componentOriginal454561be33cf1f9564870e7ee6898336 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal454561be33cf1f9564870e7ee6898336 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.deposit-btc-modals','data' => ['wallet' => $wallet,'action' => $action,'tier' => $tierId]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.deposit-btc-modals'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wallet' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($wallet),'action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($action),'tier' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($tierId)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal454561be33cf1f9564870e7ee6898336)): ?>
<?php $attributes = $__attributesOriginal454561be33cf1f9564870e7ee6898336; ?>
<?php unset($__attributesOriginal454561be33cf1f9564870e7ee6898336); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal454561be33cf1f9564870e7ee6898336)): ?>
<?php $component = $__componentOriginal454561be33cf1f9564870e7ee6898336; ?>
<?php unset($__componentOriginal454561be33cf1f9564870e7ee6898336); ?>
<?php endif; ?>
      

      <?php if (isset($component)) { $__componentOriginal93d50b8b3fb21db42dd7a246169dfb9a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal93d50b8b3fb21db42dd7a246169dfb9a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.confirm-deposit','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.confirm-deposit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal93d50b8b3fb21db42dd7a246169dfb9a)): ?>
<?php $attributes = $__attributesOriginal93d50b8b3fb21db42dd7a246169dfb9a; ?>
<?php unset($__attributesOriginal93d50b8b3fb21db42dd7a246169dfb9a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal93d50b8b3fb21db42dd7a246169dfb9a)): ?>
<?php $component = $__componentOriginal93d50b8b3fb21db42dd7a246169dfb9a; ?>
<?php unset($__componentOriginal93d50b8b3fb21db42dd7a246169dfb9a); ?>
<?php endif; ?>
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts/user/userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\user\upgrade.blade.php ENDPATH**/ ?>