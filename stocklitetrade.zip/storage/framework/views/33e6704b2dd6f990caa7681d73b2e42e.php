﻿

<?php $__env->startSection('content'); ?>



<div id="main-wrapper">
  <!-- Sidebar Start -->
  <?php if (isset($component)) { $__componentOriginal653dcfd80dd6333300d626f39c07d6a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $attributes = $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $component = $__componentOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
  <!--  Sidebar End -->

  <div class="page-wrapper">
    <!--  Header Start -->
    <?php if (isset($component)) { $__componentOriginal16952127c672c67c3b5e12b22e860292 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16952127c672c67c3b5e12b22e860292 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $attributes = $__attributesOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__attributesOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $component = $__componentOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__componentOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
    <!--  Header End -->
    <div class="body-wrapper">
      <div class="container-fluid ">
        <div class="card bg-info-subtle shadow-none position-relative overflow-hidden mb-4">
          <div class="card-body px-4 py-3">
            <div class="row align-items-center">
              <div class="col-9">
                <h4 class="fw-semibold mb-8">User Profile</h4>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                      <a class="text-muted text-decoration-none" href="/">Home</a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">User Profile</li>
                  </ol>
                </nav>
              </div>

            </div>
          </div>
        </div>
        <div class="card overflow-hidden">
          <div class="card-body p-0">
            <img src="<?php echo e(asset('user-assets/images/backgrounds/profilebg.jpg')); ?>" alt="" class="img-fluid">
            <div class="row align-items-center">

              <div class="col-lg-4 mt-n3 order-lg-2 order-1">
                <div class="mt-n5">
                  <div class="d-flex align-items-center justify-content-center mb-2">
                    <div class="d-flex align-items-center justify-content-center round-110">
                      <div
                        class="border-4 border-white d-flex align-items-center justify-content-center rounded-circle overflow-hidden round-100">
                        <img src="<?php echo e(asset(auth()->user()->avatar ?? 'user-assets/images/profile/user-1.jpg')); ?>" alt=""
                          class="w-100 h-100">
                      </div>
                    </div>
                  </div>
                  <div class="text-center">
                    <h5 class="fs-5 mb-0 fw-semibold">
                      <?php echo e(auth()->user()->name); ?>

                    </h5>
                    <p class="mb-0 fs-4">
                      <?php echo e(strtoupper(\App\Models\Tier::where('id', auth()->user()->tier)->first()->name)); ?>

                    </p>
                  </div>
                </div>
              </div>

            </div>

          </div>
        </div>

        <div class="row">
          <div class="col-lg-4">
            <div class="card shadow-none border">
              <div class="card-body">
                <h4 class="fw-semibold mb-3">Profile</h4>

                <ul class="list-unstyled mb-0">
                  <li class="d-flex align-items-center gap-6 flex-wrap mb-4">
                    <i class="ti ti-user text-dark fs-6"></i>
                    <h6 class="fs-4 fw-semibold mb-0">
                      <?php echo e(auth()->user()->name); ?>

                    </h6>
                  </li>
                  <li class="d-flex align-items-center gap-6 flex-wrap mb-4">
                    <i class="ti ti-mail text-dark fs-6"></i>
                    <h6 class="fs-4 fw-semibold mb-0">
                      <?php echo e(auth()->user()->email); ?>

                    </h6>
                  </li>
                  <li class="d-flex align-items-center gap-6 flex-wrap mb-4">
                    <i class="ti ti-phone text-dark fs-6"></i>
                    <h6 class="fs-4 fw-semibold mb-0">
                      <?php echo e(auth()->user()->phone); ?>

                    </h6>
                  </li>
                  <li class="d-flex align-items-center gap-6 flex-wrap mb-2">
                    <i class="ti ti-map-pin text-dark fs-6"></i>
                    <h6 class="fs-4 fw-semibold mb-0">
                      <?php echo e(auth()->user()->country); ?>

                    </h6>
                  </li>
                </ul>
              </div>
            </div>

          </div>
          <div class="col-lg-8 p-0">
            <div class="col-12 p-0 card shadow-none border">
              <div class=" w-100 card-body">
                <div class=" m-0 ">
                  <h5 class="card-title fw-semibold">Edit Your Profile</h5>

                  <form>
                    <div class="row">
                      <div class="col-12 mb-3 mt-3">
                        <div>
                          <label for="" class="form-label">Full Name</label>
                          <input type="text" class="form-control" id="" placeholder="FullName..."
                            value="<?php echo e(auth()->user()->name); ?>">
                        </div>
                      </div>
                      <div class="col-12 mb-3">
                        <div>
                          <label for="" class="form-label">Phone Number</label>
                          <input type="number" class="form-control" id="" placeholder="Phone Number"
                            value="<?php echo e(auth()->user()->phone); ?>">
                        </div>
                      </div>
                      <div class="col-12 mb-3">
                        <div>
                          <label for="" class="form-label">Country</label>
                          <input type="text" class="form-control" value="<?php echo e(auth()->user()->country); ?>">
                        </div>
                      </div>
                      <div class="col-12 mb-3">
                        <div>
                          <label for="" class="form-label">Email</label>
                          <input type="text" class="form-control" id="" disabled value="<?php echo e(auth()->user()->email); ?>">
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="mt-2 ">
                          To update your profile, please contact the support team.
                          <br>
                          <br>
                          <a href="mailto:support{{config('app.name')}}.com" class="btn btn-primary col-lg-6 col-12">Contact
                            Support</a>
                          
                        </div>
                      </div>
                    </div>
                  </form>

                </div>
              </div>
            </div>

          </div>
        </div>







        <?php if (isset($component)) { $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $attributes = $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $component = $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>

      </div>
      <?php if (isset($component)) { $__componentOriginal8f1c59407c428ae30b30a6af53f04baf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $attributes = $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $component = $__componentOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>




    </div>
  </div>
</div>

<script>
  function copyText(inputId) {
      var input = document.getElementById(inputId);

      if (input && input.value) {
        // Create a temporary input element
        var tempInput = document.createElement('input');
        tempInput.setAttribute('type', 'text');
        tempInput.setAttribute('value', input.value);
        document.body.appendChild(tempInput);

        // Select the text in the temporary input
        tempInput.select();
        tempInput.setSelectionRange(0, 99999); // For mobile devices

        // Copy the selected text
        document.execCommand('copy');

        // Clean up - remove the temporary input element
        document.body.removeChild(tempInput);

        // Visual feedback - change button text to 'Copied!' temporarily
        var copyButton = input.nextElementSibling.querySelector('.btn-primary');
        copyButton.innerText = 'Copied!';
        setTimeout(function() {
          copyButton.innerText = 'Copy';
        }, 1500); // Reset button text after 1.5 seconds
      }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/user/userlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\user\profile.blade.php ENDPATH**/ ?>