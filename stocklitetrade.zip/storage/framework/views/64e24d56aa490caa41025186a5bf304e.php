﻿
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalfc88abadc63b6694f60975da4d0e2187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc88abadc63b6694f60975da4d0e2187 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $attributes = $__attributesOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $component = $__componentOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__componentOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<!-- PageTitle -->
<section class="page-title">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h3 class="heading">FAQ</h3>
      </div>
      <div class="col-md-6">
        <ul class="breadcrumb">
          <li><a href="/">Home</a></li>
          <li>
            <p class="fs-18">/</p>
          </li>
          <li>
            <p class="fs-18">FAQ</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- End PageTitle -->

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <!-- FAQ 1 - Bootstrap Brain Component -->


        <div class="faq">
            <div class="block-text">
                <div class="heading">
                    <h4>Frequently Asked Questions</h4>
                </div>
            </div>

            <div class="flat-accordion">
                <div class="flat-toggle">
                    <div class="toggle-title">
                        <h6>Question 1: What is Stocklitetrade?</h6>
                    </div>
                    <div class="toggle-content">
                        <p>Stocklitetrade is a platform that allows you to smartly invest in cryptocurrencies. It provides an easy and secure way to buy and sell various digital currencies.</p>
                        <a href="#">Learn More about Investing</a>
                    </div>
                </div>

                <div class="flat-toggle">
                    <div class="toggle-title">
                        <h6>Question 2: How do I get started with Stocklitetrade?</h6>
                    </div>
                    <div class="toggle-content">
                        <p>To get started with Stocklitetrade, simply sign up on our platform. It's the easiest place to begin your cryptocurrency trading journey.</p>
                        <a href="#">Sign Up Now</a>
                    </div>
                </div>

                <div class="flat-toggle">
                    <div class="toggle-title">
                        <h6>Question 3: Is Stocklitetrade secure?</h6>
                    </div>
                    <div class="toggle-content">
                        <p>Yes, Stocklitetrade prioritizes security measures to safeguard your investments. We use advanced encryption and authentication methods to ensure a safe trading environment.</p>
                        <a href="#">Learn About Our Security Features</a>
                    </div>
                </div>
            </div>
        </div>


      </div>
    </div>
  </div>

<section class="section-sale">
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class="block-text">
          <h4 class="heading" >Signup and Earn higher profits here on Stocklitetrade</h4>
          <p class="desc">
            Discover how specific cryptocurrencies work — and get a bit of
            each crypto to try out for yourself.
          </p>
        </div>
      </div>
      <div class="col-md-5">
        <div class="button">
          <a href="#">Create Account</a>
        </div>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'FAQ',
  ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\faq.blade.php ENDPATH**/ ?>