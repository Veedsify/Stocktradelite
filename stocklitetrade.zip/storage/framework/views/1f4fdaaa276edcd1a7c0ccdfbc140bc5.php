﻿
<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalfc88abadc63b6694f60975da4d0e2187 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfc88abadc63b6694f60975da4d0e2187 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.pages.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('pages.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $attributes = $__attributesOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__attributesOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfc88abadc63b6694f60975da4d0e2187)): ?>
<?php $component = $__componentOriginalfc88abadc63b6694f60975da4d0e2187; ?>
<?php unset($__componentOriginalfc88abadc63b6694f60975da4d0e2187); ?>
<?php endif; ?>

<!-- PageTitle -->
<section class="page-title">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h3 class="heading">Register</h3>
      </div>
      <div class="col-md-6">
        <ul class="breadcrumb">
          <li><a href="/">Home</a></li>
          <li>
            <p class="fs-18">/</p>
          </li>
          <li>
            <p class="fs-18">Register</p>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- End PageTitle -->

<section class="register">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="block-text center">
          <h3 class="heading">Register To Stocklitetrade</h3>
          <p class="desc fs-20">
            Register in advance and enjoy the event benefits
          </p>
        </div>
      </div>
      <div class="col-md-12">
        <div class="flat-tabs">
          <div class="content-tab">
            <div class="content-inner">
              <form action="<?php echo e(route('register.new')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="text-center"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
                <?php endif; ?>
                <div class="form-group">
                  <label for="exampleInputEmail1">Full Name
                    <span class="fs-14">
                      <?php echo e($errors->first('fullanme')); ?>

                    </span>
                  </label>
                  <input required type="text" name="fullanme" class="form-control"
                    placeholder="Please fill in the full name." value="<?php echo e(old('fullanme')); ?>">
                </div>
                <div class="form-group">
                  <label for="exampleInputEmail1">Email Address
                    <span class="fs-14">
                      <?php echo e($errors->first('email')); ?>

                    </span>
                  </label>
                  <input required type="email" name="email" class="form-control" placeholder="Please fill in the email."
                    value="<?php echo e(old('email')); ?>">
                </div>
                <div class="form-group">
                  <label>Country
                    <span class="fs-14">
                      <?php echo e($errors->first('country')); ?>

                    </span>
                  </label>
                  <select name="country" class="form-control countriesSelect">
                    <option label="Select a country" disabled selected></option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Phone
                    <span class="fs-14">
                      <?php echo e($errors->first('phone')); ?>

                    </span></label>
                  <input required name="phone" type="text" class="form-control" placeholder="+1 234 456 7890"
                    value="<?php echo e(old('phone')); ?>">
                </div>
                <div class="form-group">
                  <label>Password
                    <span class="fs-14">
                      <?php echo e($errors->first('password')); ?>

                      <?php echo e($errors->first('confirm_password')); ?>

                    </span>
                  </label>
                  <input required type="password" name="password" class="form-control mb-3"
                    placeholder="Please enter a password." value="<?php echo e(old('password')); ?>">
                  <input required type="password" name="confirm_password" class="form-control"
                    placeholder="Please re-enter your password.">
                </div>
                <button type="submit" class="btn-action">
                  Register
                </button>
                <div class="bottom">
                  <p>Already have an account?</p>
                  <a href="<?php echo e(route('login')); ?>">Login</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="section-sale">
  <div class="container">
    <div class="row">
      <div class="col-md-7">
        <div class="block-text">
          <h4 class="heading">Signup and Earn higher profits here on Stocklitetrade</h4>
          <p class="desc">
            Discover how specific cryptocurrencies work — and get a bit of
            each crypto to try out for yourself.
          </p>
        </div>
      </div>
      <div class="col-md-5">
        <div class="button">
          <a href="#">Create Account</a>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  let selectCountries = document.querySelectorAll('.countriesSelect');
  async function GetCountries (){
    let response = await fetch('https://restcountries.com/v3.1/all');
    let data = await response.json();

    selectCountries.forEach(select => {
    data.forEach(country => {
      let option = document.createElement('option');
      option.innerText = country.name.common;
      option.value = country.name.common;
      select.appendChild(option);
    });
  })
}
GetCountries();

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', [
'title' => 'Register',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\register.blade.php ENDPATH**/ ?>