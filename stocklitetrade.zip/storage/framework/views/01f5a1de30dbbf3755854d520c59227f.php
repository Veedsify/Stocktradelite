﻿
<?php $__env->startSection('content'); ?>
<div id="main-wrapper">
    <!-- Sidebar Start -->
    <?php if (isset($component)) { $__componentOriginal653dcfd80dd6333300d626f39c07d6a5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.aside','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.aside'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $attributes = $__attributesOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__attributesOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5)): ?>
<?php $component = $__componentOriginal653dcfd80dd6333300d626f39c07d6a5; ?>
<?php unset($__componentOriginal653dcfd80dd6333300d626f39c07d6a5); ?>
<?php endif; ?>
    <!--  Sidebar End -->

    <div class="page-wrapper">
        <!--  Header Start -->
        <?php if (isset($component)) { $__componentOriginal16952127c672c67c3b5e12b22e860292 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal16952127c672c67c3b5e12b22e860292 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $attributes = $__attributesOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__attributesOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal16952127c672c67c3b5e12b22e860292)): ?>
<?php $component = $__componentOriginal16952127c672c67c3b5e12b22e860292; ?>
<?php unset($__componentOriginal16952127c672c67c3b5e12b22e860292); ?>
<?php endif; ?>
        <div class="body-wrapper">
            <div class="container-fluid">
                <!-- TradingView Widget BEGIN -->
                <div class="tradingview-widget-container">
                    <div class="tradingview-widget-container__widget"></div>
                    <script type="text/javascript"
                        src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                        {
                                "symbols": [{
                                        "proName": "FOREXCOM:SPXUSD",
                                        "title": "S&P 500 Index"
                                    },
                                    {
                                        "proName": "FOREXCOM:NSXUSD",
                                        "title": "US 100 Cash CFD"
                                    },
                                    {
                                        "proName": "FX_IDC:EURUSD",
                                        "title": "EUR to USD"
                                    },
                                    {
                                        "proName": "BITSTAMP:BTCUSD",
                                        "title": "Bitcoin"
                                    },
                                    {
                                        "proName": "BITSTAMP:ETHUSD",
                                        "title": "Ethereum"
                                    }
                                ],
                                "showSymbolLogo": true,
                                "isTransparent": true,
                                "displayMode": "adaptive",
                                "colorTheme": "light",
                                "locale": "en"
                            }
                    </script>
                </div>
                <!--  Owl carousel -->
                <div class="row">
                    <div class="col-sm-6 col-xl-4">
                        <div class="card bg-primary-subtle shadow-none">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center">
                                    <h6 class="mb-0 ">Available Balance</h6>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mt-4">
                                    <h3 class="mb-0 fw-semibold fs-7" id="user-balance"
                                        data-balance="<?php echo e(auth()->user()->balance); ?>">
                                        <?php echo e(number_format(auth()->user()->balance, 2)); ?>

                                    </h3>
                                    <span class="fw-bold"> USD</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-6 col-xl-4">
                        <div class="card bg-success-subtle shadow-none">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center">

                                    <h6 class="mb-0">BTC Equivalent</h6>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mt-4">
                                    <h3 class="mb-0 fw-semibold fs-7" id="btc-equivalent">
                                        Loading....
                                    </h3>
                                    <span class="fw-bold">BTC</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="card bg-warning-subtle shadow-none">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center">

                                    <h6 class="mb-0 ">Account Level</h6>

                                </div>
                                <div class="d-flex align-items-center justify-content-between mt-4">
                                    <h3 class="mb-0 fw-semibold fs-7">
                                        <?php echo e(strtoupper(\App\Models\Tier::where('id',
                                        auth()->user()->tier)->first()->name)); ?>

                                    </h3>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-xl-4">
                        <div class="card bg-danger-subtle shadow-none">
                            <div class="card-body p-4">
                                <div class="d-flex align-items-center">
                                    <h6 class="mb-0 ">Trades Open</h6>
                                </div>
                                <div class="d-flex align-items-center justify-content-between mt-4">
                                    <h3 class="mb-0 fw-semibold fs-7">
                                        <?php echo e(auth()->user()->trades->first()->total_count ?? 0); ?>

                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--  Row 1 -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card p-0">
                            <div class="card-body">
                                <!-- TradingView Widget BEGIN -->
                                <div class="tradingview-widget-container">
                                    <div class="tradingview-widget-container__widget"></div>
                                    <script type="text/javascript"
                                        src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js"
                                        async>
                                        {
                                  "colorTheme": "light",
                                  "dateRange": "12M",
                                  "showChart": true,
                                  "locale": "en",
                                  "width": "100%",
                                  "height": "600",
                                  "largeChartUrl": "https://google.com",
                                  "isTransparent": true,
                                  "showSymbolLogo": true,
                                  "showFloatingTooltip": false,
                                  "plotLineColorGrowing": "rgba(41, 98, 255, 1)",
                                  "plotLineColorFalling": "rgba(41, 98, 255, 1)",
                                  "gridLineColor": "rgba(240, 243, 250, 0)",
                                  "scaleFontColor": "rgba(19, 23, 34, 1)",
                                  "belowLineFillColorGrowing": "rgba(41, 98, 255, 0.12)",
                                  "belowLineFillColorFalling": "rgba(41, 98, 255, 0.12)",
                                  "belowLineFillColorGrowingBottom": "rgba(41, 98, 255, 0)",
                                  "belowLineFillColorFallingBottom": "rgba(41, 98, 255, 0)",
                                  "symbolActiveColor": "rgba(41, 98, 255, 0.12)",
                                  "tabs": [
                                    {
                                      "title": "Indices",
                                      "symbols": [
                                        {
                                          "s": "FOREXCOM:SPXUSD",
                                          "d": "S&P 500 Index"
                                        },
                                        {
                                          "s": "FOREXCOM:NSXUSD",
                                          "d": "US 100 Cash CFD"
                                        },
                                        {
                                          "s": "FOREXCOM:DJI",
                                          "d": "Dow Jones Industrial Average Index"
                                        },
                                        {
                                          "s": "INDEX:NKY",
                                          "d": "Nikkei 225"
                                        },
                                        {
                                          "s": "INDEX:DEU40",
                                          "d": "DAX Index"
                                        },
                                        {
                                          "s": "FOREXCOM:UKXGBP",
                                          "d": "FTSE 100 Index"
                                        }
                                      ],
                                      "originalTitle": "Indices"
                                    },
                                    {
                                      "title": "Futures",
                                      "symbols": [
                                        {
                                          "s": "CME_MINI:ES1!",
                                          "d": "S&P 500"
                                        },
                                        {
                                          "s": "CME:6E1!",
                                          "d": "Euro"
                                        },
                                        {
                                          "s": "COMEX:GC1!",
                                          "d": "Gold"
                                        },
                                        {
                                          "s": "NYMEX:CL1!",
                                          "d": "WTI Crude Oil"
                                        },
                                        {
                                          "s": "NYMEX:NG1!",
                                          "d": "Gas"
                                        },
                                        {
                                          "s": "CBOT:ZC1!",
                                          "d": "Corn"
                                        }
                                      ],
                                      "originalTitle": "Futures"
                                    },
                                    {
                                      "title": "Bonds",
                                      "symbols": [
                                        {
                                          "s": "CBOT:ZB1!",
                                          "d": "T-Bond"
                                        },
                                        {
                                          "s": "CBOT:UB1!",
                                          "d": "Ultra T-Bond"
                                        },
                                        {
                                          "s": "EUREX:FGBL1!",
                                          "d": "Euro Bund"
                                        },
                                        {
                                          "s": "EUREX:FBTP1!",
                                          "d": "Euro BTP"
                                        },
                                        {
                                          "s": "EUREX:FGBM1!",
                                          "d": "Euro BOBL"
                                        }
                                      ],
                                      "originalTitle": "Bonds"
                                    },
                                    {
                                      "title": "Forex",
                                      "symbols": [
                                        {
                                          "s": "FX:EURUSD",
                                          "d": "EUR to USD"
                                        },
                                        {
                                          "s": "FX:GBPUSD",
                                          "d": "GBP to USD"
                                        },
                                        {
                                          "s": "FX:USDJPY",
                                          "d": "USD to JPY"
                                        },
                                        {
                                          "s": "FX:USDCHF",
                                          "d": "USD to CHF"
                                        },
                                        {
                                          "s": "FX:AUDUSD",
                                          "d": "AUD to USD"
                                        },
                                        {
                                          "s": "FX:USDCAD",
                                          "d": "USD to CAD"
                                        }
                                      ],
                                      "originalTitle": "Forex"
                                    }
                                  ]
                                }
                                    </script>
                                </div>
                                <!-- TradingView Widget END -->
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row">
                            <div class="col-lg-12 col-md-6">
                                <!-- Monthly Earnings -->
                                <div class="card">
                                    <div class="card-body">
                                        <!-- TradingView Widget BEGIN -->
                                        <div class="tradingview-widget-container">
                                            <div class="tradingview-widget-container__widget"></div>
                                            <script type="text/javascript"
                                                src="https://s3.tradingview.com/external-embedding/embed-widget-technical-analysis.js"
                                                async>
                                                {
                                      "interval": "1m",
                                      "width": "100%",
                                      "isTransparent": true,
                                      "height": "600",
                                      "symbol": "BITSTAMP:BTCUSD",
                                      "showIntervalTabs": true,
                                      "displayMode": "multiple",
                                      "locale": "en",
                                      "colorTheme": "light",
                                      "largeChartUrl": "https://google.com"
                                    }
                                            </script>
                                        </div>
                                        <!-- TradingView Widget END -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="card w-100">
                        <div class="card-header anime py-2" style="border-bottom: 1px solid #eee;">
                            Live Trade Session
                        </div>
                        <div class="card-body p-0">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div id="tradingview_19631">
                                    <div id="tradingview_bffd7-wrapper"
                                        style="position: relative; box-sizing: content-box; font-family: -apple-system, BlinkMacSystemFont, &quot;Trebuchet MS&quot;, Roboto, Ubuntu, sans-serif; margin: 0px auto !important; padding: 0px !important; width: auto; height: calc(568px);">
                                        <iframe title="advanced chart TradingView widget" lang="en"
                                            id="tradingview_bffd7" frameborder="0" allowtransparency="true"
                                            scrolling="no" allowfullscreen="true"
                                            src="https://s.tradingview.com/widgetembed/?hideideas=1&amp;overrides=%7B%7D&amp;enabled_features=%5B%5D&amp;disabled_features=%5B%5D&amp;locale=en#%7B%22symbol%22%3A%22COINBASE%3ABTCUSD%22%2C%22frameElementId%22%3A%22tradingview_bffd7%22%2C%22interval%22%3A%22D%22%2C%22allow_symbol_change%22%3A%221%22%2C%22save_image%22%3A%221%22%2C%22hotlist%22%3A%221%22%2C%22studies%22%3A%22%5B%5D%22%2C%22theme%22%3A%22Dark%22%2C%22style%22%3A%220%22%2C%22timezone%22%3A%22Etc%2FUTC%22%2C%22studies_overrides%22%3A%22%7B%7D%22%2C%22utm_source%22%3A%22www.elitestacksmarkets.com%22%2C%22utm_medium%22%3A%22widget_new%22%2C%22utm_campaign%22%3A%22chart%22%2C%22utm_term%22%3A%22COINBASE%3ABTCUSD%22%2C%22page-uri%22%3A%22www.elitestacksmarkets.com%2Faccount%2Findex.php%22%7D"
                                            style="width: 100%; height: 100%; margin: 0px !important; padding: 0px !important;"></iframe>
                                    </div>
                                </div>
                                <div class="tradingview-widget-copyright" style="width: 100%;"></div>
                                <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                                <script type="text/javascript">
                                    new TradingView.widget({
                                            "width": "auto",
                                            "height": 600,
                                            "symbol": "COINBASE:BTCUSD",
                                            "interval": "D",
                                            "timezone": "Etc/UTC",
                                            "theme": "Light",
                                            "style": "0",
                                            "locale": "en",
                                            "toolbar_bg": "#ffffff",
                                            "enable_publishing": false,
                                            "allow_symbol_change": true,
                                            "hotlist": true,
                                            "container_id": "tradingview_19631"
                                        });
                                </script>
                            </div>
                            <!-- TradingView Widget END -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if (isset($component)) { $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.canvas','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.canvas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $attributes = $__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__attributesOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4)): ?>
<?php $component = $__componentOriginalabcddb3d8e134b0703b989925ff6e7d4; ?>
<?php unset($__componentOriginalabcddb3d8e134b0703b989925ff6e7d4); ?>
<?php endif; ?>

    </div>
    <?php if (isset($component)) { $__componentOriginal8f1c59407c428ae30b30a6af53f04baf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.user.search','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('user.search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $attributes = $__attributesOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__attributesOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf)): ?>
<?php $component = $__componentOriginal8f1c59407c428ae30b30a6af53f04baf; ?>
<?php unset($__componentOriginal8f1c59407c428ae30b30a6af53f04baf); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts/user/userlayout', [
'title' => ucwords(auth()->user()->name) . ' | Dashboard - Stocklitetrade',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dike Wisdom\Desktop\Files\Documents\Active Website Projects\Stocktradelite\website\resources\views\user\user.blade.php ENDPATH**/ ?>